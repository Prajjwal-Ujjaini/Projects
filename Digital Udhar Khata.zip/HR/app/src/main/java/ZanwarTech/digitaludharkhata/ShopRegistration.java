package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShopRegistration extends AppCompatActivity implements WEB_URL {
    EditText etCRName,etCRPwd;
    String strCRMno,strCRName,strCRPwd;
    ProgressBar pbCR;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_registration);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);

        etCRName=findViewById(R.id.etCRName);
        etCRPwd=findViewById(R.id.etCRPwd);

        pbCR=findViewById(R.id.pbCR);
    }

    public void addShop(View view){
        strCRMno=sharedPreferences.getString("MNO","DEFAULT MNO");
        strCRName=etCRName.getText().toString().trim();
        strCRPwd=etCRPwd.getText().toString().trim();

        if (strCRMno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(strCRPwd)){
            Toast.makeText(getApplicationContext(), "Please enter password", Toast.LENGTH_SHORT).show();
            return;
        }
        if (strCRPwd.length() < 6) {
            Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TextUtils.isEmpty(strCRName) && !TextUtils.isEmpty(strCRMno) && !TextUtils.isEmpty(strCRPwd)) {
            pbCR.setVisibility(View.VISIBLE);

            final Map map=new HashMap();
            map.put("s_name",strCRName );
            map.put("s_mno",strCRMno );
            map.put("s_pwd",strCRPwd );

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            //Toast.makeText(this, "after request", Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupName, Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupMno, Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, strSignupPwd, Toast.LENGTH_SHORT).show();
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Url + "add_shop.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        String data=jsonObject.getString("success");

                        //Toast.makeText(getApplicationContext(), "data ="+data, Toast.LENGTH_SHORT).show();
                        //Toast.makeText(getApplicationContext(), "in try after json  ", Toast.LENGTH_SHORT).show();

                        if(data.equals("1")){
                            //  Toast.makeText(getApplicationContext(), "this is running equals 1", Toast.LENGTH_SHORT).show();
                            //Proreass bar show
                            Intent intent=new Intent(getApplicationContext(),ShopLogin.class);
                            Toast.makeText(getApplicationContext(), "Regristration success full !! Please login with your cradentials!!", Toast.LENGTH_SHORT).show();
                            pbCR.setVisibility(View.GONE);

                            try{
                                SharedPreferences spCustomerRegristration=getSharedPreferences("SP",MODE_PRIVATE);
                                SharedPreferences.Editor editorCR=spCustomerRegristration.edit();
                                editorCR.putString("CustomerName",strCRName);
                                editorCR.putString("CustomerMno",strCRMno);
                                editorCR.commit();
                            }catch (Exception e){
                                Toast.makeText(ShopRegistration.this, "catch in shared P=="+e.toString(), Toast.LENGTH_SHORT).show();
                            }

                            startActivity(intent);
                        }else{
                            pbCR.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Not Regristered", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbCR.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), /*"catch run ==="+*/ e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbCR.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), " error listnor run :==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueue.add(stringRequest);

            etCRName.setText("");
//            etSignupMno.setText("");
            etCRPwd.setText("");
        } else {
            pbCR.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
