package ZanwarTech.digitaludharkhata.AllFrames;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.digitaludharkhata.Adapters.CustomerListAdapter;
import ZanwarTech.digitaludharkhata.Details.CustomerDetails;
import ZanwarTech.digitaludharkhata.PerticularCustomer;
import ZanwarTech.digitaludharkhata.R;
import ZanwarTech.digitaludharkhata.WEB_URL;

public class ShopDashboards extends Fragment implements WEB_URL {
    ProgressBar pbSD;

    ListView lvSD;
    List<CustomerDetails> customerDetailsList;
    CustomerListAdapter customerListAdapter;


    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String sId;

    FragmentTransaction fragmentTransaction;
    FragmentManager fragmentManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view= inflater.inflate(R.layout.fragment_shop_dashboards, container, false);

        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();


        pbSD=view.findViewById(R.id.pbSD);
        //btnAddCustomer=view.findViewById(R.id.btnAddCustomer);
        lvSD=view.findViewById(R.id.lvSD);

        customerDetailsList=new ArrayList<>();
        sharedPreferences=view.getContext().getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
        sId=sharedPreferences.getString("ShopId","DEFAULT Sid");

        getCustomerList();

        lvSD.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(ShopDashboard.this, customerDetailsList.get(position).getScName(), Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getContext(), PerticularCustomer.class);
                editor.putString("scId", customerDetailsList.get(position).getScId());
                editor.putString("CustomerName",customerDetailsList.get(position).getScName());
                editor.commit();
                startActivity(intent);
            }
        });

        return view;
    }

    private void getCustomerList() {
        pbSD.setVisibility(View.VISIBLE);
        final Map map=new HashMap();
        map.put("s_id",sId);
        RequestQueue requestQueueMyOrder= Volley.newRequestQueue(getContext());
        StringRequest stringRequestMyOrder=new StringRequest(Request.Method.POST,Url+"see_perticular_shop_customer.php" , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //   Toast.makeText(MyOrders.this, response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObjectMyOrder=new JSONObject(response);
                    JSONArray jsonArrayMyOrder=jsonObjectMyOrder.getJSONArray("students");
                    pbSD.setVisibility(View.GONE);
                    for (int i=0;i<jsonArrayMyOrder.length();i++){
                        JSONObject tmpcumtomer=jsonArrayMyOrder.getJSONObject(i);

                        CustomerDetails customerList=new CustomerDetails(tmpcumtomer.getString("sc_id"),tmpcumtomer.getString("s_id"),
                                tmpcumtomer.getString("sc_name"),tmpcumtomer.getString("sc_mno"),
                                tmpcumtomer.getString("sc_doa"));
                        customerDetailsList.add(customerList);
                    }
                    customerListAdapter =new CustomerListAdapter(getContext(),customerDetailsList);
                    lvSD.setAdapter(customerListAdapter);
                } catch (JSONException e) {
                    pbSD.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(getContext(), "catch error=="+e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pbSD.setVisibility(View.GONE);
                Toast.makeText(getContext(), "error in response ==="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        requestQueueMyOrder.add(stringRequestMyOrder);
    }

}
