package ZanwarTech.digitaludharkhata.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import ZanwarTech.digitaludharkhata.Details.CustomerDetails;
import ZanwarTech.digitaludharkhata.R;

public class CustomerListAdapter extends BaseAdapter {
    Context context;
    List<CustomerDetails> customerDetailsList;

    public CustomerListAdapter(Context context, List<CustomerDetails> customerDetailsList) {
        this.context = context;
        this.customerDetailsList = customerDetailsList;
    }

    @Override
    public int getCount() {
        return customerDetailsList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView lvCName,lvCMno;
        View view=LayoutInflater.from(context).inflate(R.layout.lv_customer,null);

        lvCName=view.findViewById(R.id.lvCName);
        lvCMno=view.findViewById(R.id.lvCMno);

        lvCName.setText(customerDetailsList.get(position).getScName());
        lvCMno.setText(customerDetailsList.get(position).getScMno());
        return view;
    }
}
