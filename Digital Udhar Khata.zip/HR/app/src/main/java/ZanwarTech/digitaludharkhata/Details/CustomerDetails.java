package ZanwarTech.digitaludharkhata.Details;

import java.io.Serializable;

public class CustomerDetails implements Serializable {
    String scId,sId,scName,scMno,scDoa;

    public CustomerDetails(String scId, String sId, String scName, String scMno, String scDoa) {
        this.scId = scId;
        this.sId = sId;
        this.scName = scName;
        this.scMno = scMno;
        this.scDoa = scDoa;
    }

    public CustomerDetails(String sId, String scName, String scMno, String scDoa) {
        this.sId = sId;
        this.scName = scName;
        this.scMno = scMno;
        this.scDoa = scDoa;
    }

    public String getScId() {
        return scId;
    }

    public void setScId(String scId) {
        this.scId = scId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getScName() {
        return scName;
    }

    public void setScName(String scName) {
        this.scName = scName;
    }

    public String getScMno() {
        return scMno;
    }

    public void setScMno(String scMno) {
        this.scMno = scMno;
    }

    public String getScDoa() {
        return scDoa;
    }

    public void setScDoa(String scDoa) {
        this.scDoa = scDoa;
    }
}
