package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class CheckOTP extends AppCompatActivity {
    EditText etCOTP;
    String strCotp,OTP;
    ProgressBar pbC;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_o_t_p);

        sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);

        etCOTP=findViewById(R.id.etCOTP);
        strCotp=etCOTP.getText().toString().trim();
        pbC=findViewById(R.id.pbC);
    }
    public void checkOtp(View view){
        OTP=sharedPreferences.getString("OTP","OTP DEFAULT");
        strCotp=etCOTP.getText().toString().trim();
        //Toast.makeText(this, "OTP+=="+OTP, Toast.LENGTH_SHORT).show();
        //Toast.makeText(this, "strVerfyOTP=="+strVerifyOTP, Toast.LENGTH_SHORT).show();

        pbC.setVisibility(View.VISIBLE);
        if(OTP.equals(strCotp)){
            Intent intent=new Intent(getApplicationContext(), ShopRegistration.class);
            pbC.setVisibility(View.GONE);
            startActivity(intent);
        }
        else {
            pbC.setVisibility(View.GONE);
            Toast.makeText(this, "Please Enter Correct OTP", Toast.LENGTH_SHORT).show();
        }
    }
}
