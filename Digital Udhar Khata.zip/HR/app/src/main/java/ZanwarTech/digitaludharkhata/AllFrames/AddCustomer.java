package ZanwarTech.digitaludharkhata.AllFrames;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import ZanwarTech.digitaludharkhata.NavigationDrawer;
import ZanwarTech.digitaludharkhata.R;
import ZanwarTech.digitaludharkhata.WEB_URL;

public class AddCustomer extends Fragment implements WEB_URL {

    EditText etAcName,etAcMno;
    String sId,scName,scMno,scDoa;
    Button btnAcSave;

    SimpleDateFormat simpleDateFormat;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    ProgressBar pbAC;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_add_customer, container, false);

        etAcName=view.findViewById(R.id.etAcName);
        etAcMno=view.findViewById(R.id.etAcMno);
        pbAC=view.findViewById(R.id.pbAC);
        btnAcSave=view.findViewById(R.id.btnAcSave);

        simpleDateFormat=new SimpleDateFormat("MM/dd/yyyy");
        scDoa=simpleDateFormat.format(new Date());


        sharedPreferences=view.getContext().getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        sId=sharedPreferences.getString("ShopId","DEFAULT Sid");

       // Toast.makeText(getContext(), sId, Toast.LENGTH_SHORT).show();

        btnAcSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCustomer(v);
            }
        });
        return view;
    }

    public void addCustomer(View view){
        scName=etAcName.getText().toString().trim();
        scMno=etAcMno.getText().toString().trim();
        if (!TextUtils.isEmpty(scName) && !TextUtils.isEmpty(scMno)){
            pbAC.setVisibility(View.VISIBLE);
            final Map map=new HashMap();
            map.put("s_id",sId);
            map.put("sc_name",scName);
            map.put("sc_mno",scMno);
            map.put("sc_doa",scDoa);
            RequestQueue requestQueueAddCustomer = Volley.newRequestQueue(view.getContext());
            StringRequest stringRequestAddCustomer=new StringRequest(Request.Method.POST, Url+"add_shop_customer.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                    try {
                        JSONObject jsonObjectConfirmPage=new JSONObject(response);
                        //  Toast.makeText(getContext(), jsonObjectConfirmPage.toString(), Toast.LENGTH_SHORT).show();
                        String data=jsonObjectConfirmPage.getString("success");
                        //  Toast.makeText(ConfirmPage.this, "data on confirm page="+data, Toast.LENGTH_SHORT).show();

                        if(data.equals("1")){
                            Toast.makeText(getContext(), "Customer Saved", Toast.LENGTH_SHORT).show();
                            pbAC.setVisibility(View.GONE);
                            Intent intent=new Intent(getContext(), NavigationDrawer.class);
                            startActivity(intent);

                            editor.putString("CustomerName",scName);
                            editor.commit();
                        }else {
                            pbAC.setVisibility(View.GONE);
                            Toast.makeText(getContext(), "Customer not Saved", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbAC.setVisibility(View.GONE);
                        Toast.makeText(getContext(), "catch run ==="+ e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbAC.setVisibility(View.GONE);
                    Toast.makeText(getContext(), " error listnor run  on Confirm page:==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueueAddCustomer.add(stringRequestAddCustomer);
        }else {
            pbAC.setVisibility(View.GONE);
            Toast.makeText(getContext(), "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
