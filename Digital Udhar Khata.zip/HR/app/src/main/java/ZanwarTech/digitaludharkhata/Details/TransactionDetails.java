package ZanwarTech.digitaludharkhata.Details;

import java.io.Serializable;

public class TransactionDetails implements Serializable {
    String tId,scId,giveAmount,givenDate,gotAmount,gotDate;

    public TransactionDetails(String tId, String scId, String giveAmount, String givenDate, String gotAmount, String gotDate) {
        this.tId = tId;
        this.scId = scId;
        this.giveAmount = giveAmount;
        this.givenDate = givenDate;
        this.gotAmount = gotAmount;
        this.gotDate = gotDate;
    }

    public String gettId() {
        return tId;
    }

    public void settId(String tId) {
        this.tId = tId;
    }

    public String getScId() {
        return scId;
    }

    public void setScId(String scId) {
        this.scId = scId;
    }

    public String getGiveAmount() {
        return giveAmount;
    }

    public void setGiveAmount(String giveAmount) {
        this.giveAmount = giveAmount;
    }

    public String getGivenDate() {
        return givenDate;
    }

    public void setGivenDate(String givenDate) {
        this.givenDate = givenDate;
    }

    public String getGotAmount() {
        return gotAmount;
    }

    public void setGotAmount(String gotAmount) {
        this.gotAmount = gotAmount;
    }

    public String getGotDate() {
        return gotDate;
    }

    public void setGotDate(String gotDate) {
        this.gotDate = gotDate;
    }
}
