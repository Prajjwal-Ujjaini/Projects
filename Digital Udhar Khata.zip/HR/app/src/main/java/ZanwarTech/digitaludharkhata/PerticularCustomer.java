package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.digitaludharkhata.Adapters.CustomerListAdapter;
import ZanwarTech.digitaludharkhata.Adapters.TransactionAdapter;
import ZanwarTech.digitaludharkhata.Details.CustomerDetails;
import ZanwarTech.digitaludharkhata.Details.TransactionDetails;

import static ZanwarTech.digitaludharkhata.WEB_URL.Url;

public class PerticularCustomer extends AppCompatActivity {

    ProgressBar pbPC;
    TextView txtPCName;
    String customerName,scId;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    ListView lvPC;
    List<TransactionDetails> transactionDetailsList;
    TransactionAdapter transactionAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perticular_customer);

        pbPC=findViewById(R.id.pbPC);
        txtPCName=findViewById(R.id.txtPCName);
        lvPC=findViewById(R.id.lvPC);

        transactionDetailsList=new ArrayList<>();

        sharedPreferences=getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
        customerName=sharedPreferences.getString("CustomerName","DEFAULT CustomerName");
        scId=sharedPreferences.getString("scId","DEFAULT scId");
        txtPCName.setText(customerName);

        getTransactionList();
    }

    private void getTransactionList() {
        pbPC.setVisibility(View.VISIBLE);

        final Map map=new HashMap();
        map.put("sc_id",scId);
        RequestQueue requestQueueMyOrder= Volley.newRequestQueue(this);
        StringRequest stringRequestMyOrder=new StringRequest(Request.Method.POST,Url+"see_perticular_customer_transaction.php" , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //   Toast.makeText(MyOrders.this, response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonObjectMyOrder=new JSONObject(response);
                    JSONArray jsonArrayMyOrder=jsonObjectMyOrder.getJSONArray("students");
                    pbPC.setVisibility(View.GONE);
                    for (int i=0;i<jsonArrayMyOrder.length();i++){
                        JSONObject tmpPC=jsonArrayMyOrder.getJSONObject(i);

                        TransactionDetails transactionPC=new TransactionDetails(tmpPC.getString("t_id"),tmpPC.getString("sc_id"),
                                tmpPC.getString("give_amount"),tmpPC.getString("given_date"),
                                tmpPC.getString("got_amount"),tmpPC.getString("got_date"));
                        transactionDetailsList.add(transactionPC);
                    }
                    transactionAdapter =new TransactionAdapter(getApplicationContext(),transactionDetailsList);
                    lvPC.setAdapter(transactionAdapter);
                } catch (JSONException e) {
                    pbPC.setVisibility(View.GONE);
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "This is your First Transaction", Toast.LENGTH_SHORT).show();
                    //Toast.makeText(getApplicationContext(), "catch error=="+e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pbPC.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "error in response ==="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        requestQueueMyOrder.add(stringRequestMyOrder);
    }


    public void gotoGave(View view){
        Intent intent=new Intent(this,Gave.class);
        startActivity(intent);
    }
    public void gotoGot(View view){
        Intent intent=new Intent(this,Got.class);
        startActivity(intent);
    }


}
