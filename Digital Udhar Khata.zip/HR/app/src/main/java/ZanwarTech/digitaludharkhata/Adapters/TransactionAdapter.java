package ZanwarTech.digitaludharkhata.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

import ZanwarTech.digitaludharkhata.Details.TransactionDetails;
import ZanwarTech.digitaludharkhata.R;

public class TransactionAdapter extends BaseAdapter {

    Context context;
    List<TransactionDetails> transactionDetailsList;

    public TransactionAdapter(Context context, List<TransactionDetails> transactionDetailsList) {
        this.context = context;
        this.transactionDetailsList = transactionDetailsList;
    }

    @Override
    public int getCount() {
        return transactionDetailsList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView txtlvPLDate,txtlvPLGave,txtlvPLGot;
        String strGivenDate,strGaveAmount,strGotDate,strGotAmount;
        View view=LayoutInflater.from(context).inflate(R.layout.lv_transaction, null);
        txtlvPLDate=view.findViewById(R.id.txtlvPLDate);
        txtlvPLGave=view.findViewById(R.id.txtlvPLGave);
        txtlvPLGot=view.findViewById(R.id.txtlvPLGot);

        strGivenDate=transactionDetailsList.get(position).getGivenDate();
        strGaveAmount=transactionDetailsList.get(position).getGiveAmount();
        strGotDate=transactionDetailsList.get(position).getGotDate();
        strGotAmount=transactionDetailsList.get(position).getGotAmount();

        if(strGaveAmount.isEmpty() && strGivenDate.isEmpty()){
            txtlvPLDate.setText(transactionDetailsList.get(position).getGotDate());
            txtlvPLGave.setText("      ");
            txtlvPLGot.setText(transactionDetailsList.get(position).getGotAmount());
        }else {
            txtlvPLDate.setText(transactionDetailsList.get(position).getGivenDate());
            txtlvPLGave.setText(transactionDetailsList.get(position).getGiveAmount());
            txtlvPLGot.setText("      ");
        }
        return view;
    }
}
