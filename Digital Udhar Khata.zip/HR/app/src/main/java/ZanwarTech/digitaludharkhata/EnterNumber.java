package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EnterNumber extends AppCompatActivity implements WEB_URL {
    EditText etRMno;
    String strRMno,OTP;
    ProgressBar pbR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_number);

        etRMno=findViewById(R.id.etRMNO);
        strRMno=etRMno.getText().toString().trim();
        pbR=findViewById(R.id.pbR);
    }
    public void getOTP(View view){
        strRMno=etRMno.getText().toString();
        if (strRMno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        pbR.setVisibility(View.VISIBLE);
        final Map map=new HashMap();
        map.put("s_mno",strRMno);
        RequestQueue regRequestQueue= Volley.newRequestQueue(this);
        StringRequest regStringRequest=new StringRequest(Request.Method.POST, Url + "otp_mno.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Log.e("response:", response);
                //Toast.makeText(getApplicationContext(), "response:" + response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject vrfyJsonObject=new JSONObject(response);
                    String data=vrfyJsonObject.getString("success");//to check user already exist used in if
                    String otptmp=vrfyJsonObject.getString("otp"); //temp to reslove errror

                    //String otp=vrfyJsonObject.getString("otp");
                    // Toast.makeText(Verification.this, "jason=="+vrfyJsonObject, Toast.LENGTH_SHORT).show();
                    // Toast.makeText(Verification.this, "data=="+data, Toast.LENGTH_SHORT).show();
                    // Toast.makeText(Verification.this, "otp=="+otptmp, Toast.LENGTH_SHORT).show();

                    if(data.equals("1")){
                        try{
                            //Toast.makeText(Verification.this, "in if come in try", Toast.LENGTH_SHORT).show();
                            pbR.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "this mobile no is already exist please use diffrent one", Toast.LENGTH_SHORT).show();
                        }catch (Exception e){
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "catch error try inside try="+e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        //Toast.makeText(Verification.this, "in else of  data.equals(\"1\")=", Toast.LENGTH_SHORT).show();
                        OTP = vrfyJsonObject.getString("otp");

                        SharedPreferences sharedPreferences=getSharedPreferences("SP",MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedPreferences.edit();
                        editor.putString("OTP",OTP);
                        editor.putString("MNO",strRMno);
                        editor.commit();

                        pbR.setVisibility(View.GONE);
                       // Toast.makeText(getApplicationContext(), "Please enter Otp and check", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(getApplicationContext(),CheckOTP.class);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    pbR.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), "catch error in verfy="+e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error in response error",error.toString());
                pbR.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), " error listnor run :==="+error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return map;
            }
        };
        regRequestQueue.add(regStringRequest);
    }
}
