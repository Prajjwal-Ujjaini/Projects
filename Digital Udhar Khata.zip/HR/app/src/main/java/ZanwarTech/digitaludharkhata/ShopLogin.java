package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import ZanwarTech.digitaludharkhata.Details.ShopDetails;

public class ShopLogin extends AppCompatActivity implements WEB_URL {
    private EditText etLMno,etLPwd;
    private String strLoginCMno,strLoginCPwd;

    ProgressBar pbL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_login);

        etLMno=findViewById(R.id.etLoginMno);
        etLPwd=findViewById(R.id.etLoginPwd);
        pbL=findViewById(R.id.pbL);

    }

    public void loginShop(View view){
        strLoginCMno=etLMno.getText().toString().trim();
        strLoginCPwd=etLPwd.getText().toString().trim();

        if (strLoginCMno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TextUtils.isEmpty(strLoginCMno) && !TextUtils.isEmpty(strLoginCPwd)){
            pbL.setVisibility(View.VISIBLE);

            final Map map = new HashMap();
            map.put("s_mno",strLoginCMno);
            map.put("s_pwd", strLoginCPwd);

            try{
                RequestQueue queue= Volley.newRequestQueue(this);
                StringRequest request=new StringRequest(Request.Method.POST, Url + "login_shop.php", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.e("response:", response);
                       // Toast.makeText(getApplicationContext(), "response:" + response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            String data=jsonObject.getString("success");

                            if(data.equals("1")){
                                Toast.makeText(getApplicationContext(), "logged in", Toast.LENGTH_SHORT).show();

                                //Toast.makeText(LoginCustomer.this, "TERRRRRRR="+jsonObject, Toast.LENGTH_LONG).show();

                                Intent intent=new Intent(getApplicationContext(),NavigationDrawer.class);

                                ShopDetails shopDetails;
                                shopDetails=new ShopDetails();

                                shopDetails.setShopID(jsonObject.getString("s_id"));
                                shopDetails.setShopName(jsonObject.getString("s_name"));
                                shopDetails.setShopMno(jsonObject.getString("s_mno"));


                                //Intent intent=new Intent(Login_in.this,Customer_Profile.class);//working
                                //startActivity(intent);//working
                                //Toast.makeText(LoginCustomer.this,"customerdetail="+customerDetails.getCstmr_mno() , Toast.LENGTH_SHORT).show();

                                try{
                                    SharedPreferences spLogin=getSharedPreferences("SP",MODE_PRIVATE);
                                    SharedPreferences.Editor editorLogin=spLogin.edit();
                                    editorLogin.putString("ShopId",shopDetails.getShopID());
                                    editorLogin.putString("ShopName",shopDetails.getShopName());
                                    editorLogin.putString("ShopMno",shopDetails.getShopMno());
                                    //Toast.makeText(LoginCustomer.this, "tty=="+editorLogin.putString("CustomerName",customerDetails.getCstmr_name()).toString(), Toast.LENGTH_SHORT).show();
                                    editorLogin.apply();
                                }catch (Exception e){
                                    Toast.makeText(getApplicationContext(), "catch in shared=="+e.toString(), Toast.LENGTH_SHORT).show();
                                }

                                pbL.setVisibility(View.GONE);
                                startActivity(intent);
                            }else{
                                pbL.setVisibility(View.GONE);
                                Toast.makeText(getApplicationContext(), " Please provide correct Moblie Number or Password", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Log.e("catch error:", e.toString());
                            pbL.setVisibility(View.GONE);
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "(*&^==="+e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error", error.toString());
                        pbL.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        return map;
                    }
                };
                queue.add(request);
            }catch (Exception e){
                pbL.setVisibility(View.GONE);
                Log.e("e:",e.toString());
                Toast.makeText(this, "$$=="+e.toString(), Toast.LENGTH_SHORT).show();
            }

           etLMno.setText("");
           etLPwd.setText("");
        } else {
            pbL.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
