package ZanwarTech.digitaludharkhata.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import ZanwarTech.digitaludharkhata.R;

public class ChooseLanuageAdapter extends BaseAdapter {
    Context contextCL;
    String stringlist[];

    public ChooseLanuageAdapter(Context contextCL, String[] stringlist) {
        this.contextCL = contextCL;
        this.stringlist = stringlist;
    }

    @Override
    public int getCount() {
        return stringlist.length;
    }

     @Override
    public Object getItem(int position) {
        return null;
    }

     @Override
    public long getItemId(int position) {
        return 0;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView gvTxtLanguage;
        View view=LayoutInflater.from(contextCL).inflate(R.layout.gv_choose_language,null);
        gvTxtLanguage=view.findViewById(R.id.gvTxtLanguage);

        gvTxtLanguage.setText(stringlist[position]);

        return view;
    }
}
