package ZanwarTech.digitaludharkhata;

public interface WEB_URL {
    String Url="https://zanwar.000webhostapp.com/Digital_Udhar_Khata/";

}
