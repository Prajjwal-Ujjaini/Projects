package ZanwarTech.digitaludharkhata.Details;

import java.io.Serializable;

public class ShopDetails implements Serializable {
    String shopID,shopName,shopMno;

    public ShopDetails() {
    }

    public ShopDetails(String shopID, String shopName, String shopMno) {
        this.shopID = shopID;
        this.shopName = shopName;
        this.shopMno = shopMno;
    }

    public String getShopID() {
        return shopID;
    }

    public void setShopID(String shopID) {
        this.shopID = shopID;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopMno() {
        return shopMno;
    }

    public void setShopMno(String shopMno) {
        this.shopMno = shopMno;
    }
}
