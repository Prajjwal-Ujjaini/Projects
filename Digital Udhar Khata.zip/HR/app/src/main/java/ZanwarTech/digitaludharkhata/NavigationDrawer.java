package ZanwarTech.digitaludharkhata;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ZanwarTech.digitaludharkhata.Adapters.CustomerListAdapter;
import ZanwarTech.digitaludharkhata.AllFrames.AboutUs;
import ZanwarTech.digitaludharkhata.AllFrames.AddCustomer;
import ZanwarTech.digitaludharkhata.AllFrames.CustomerList;
import ZanwarTech.digitaludharkhata.AllFrames.Profile;
import ZanwarTech.digitaludharkhata.AllFrames.ShopDashboards;
import ZanwarTech.digitaludharkhata.AllFrames.SignOut;
import ZanwarTech.digitaludharkhata.Details.CustomerDetails;

public class NavigationDrawer extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ActionBarDrawerToggle toggle;
    Button btn;


    TextView txtNvName,txtNvMno;
    String shopId,shopName,shopMno;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);


        drawerLayout=findViewById(R.id.draw_layout);

       btn=findViewById(R.id.btnAddCustomer);

        toggle=new ActionBarDrawerToggle(this,drawerLayout,R.string.navi_open,R.string.navi_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        NavigationView navigationView=(NavigationView)findViewById(R.id.nv);
        setupDrawableContent(navigationView);

        View headView=navigationView.getHeaderView(0);

        txtNvName=headView.findViewById(R.id.txtNvName);
        txtNvMno=headView.findViewById(R.id.txtNvMno);

        sharedPreferences=getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        shopId=sharedPreferences.getString("ShopId","DEFAULT Sid");
        shopName=sharedPreferences.getString("ShopName","DEFAULT Shop Name");
        shopMno=sharedPreferences.getString("ShopMno","DEFAULT Shop Mno");

        txtNvName.setText(shopName);
        txtNvMno.setText(shopMno);






        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment fragments=null;
                Class fragmentClass;
                fragmentClass = AddCustomer.class;

                try {
                    fragments=(Fragment) fragmentClass.newInstance();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (java.lang.InstantiationException e) {
                    e.printStackTrace();
                }
                FragmentManager fragmentManager=getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.frgDb,fragments).commit();

                btn.setVisibility(View.GONE);
            }
        });
    }

    private void setupDrawableContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                selectItemDrawer(item);
                return false;
            }
        });
    }

    private void selectItemDrawer(MenuItem item) {
        Fragment fragment=null;
        Class fragmentClass;
        switch (item.getItemId()){
            //case R.id.dbProfile:
              //  fragmentClass = Profile.class;
                //break;
            case R.id.dbShopDashboard:
                fragmentClass = ShopDashboards.class;
                break;
            case R.id.dbAddCustomer:
                fragmentClass = AddCustomer.class;
                break;
            case R.id.dbAboutUs:
                fragmentClass = AboutUs.class;
                break;
            case R.id.dbSignout:
                fragmentClass = SignOut.class;
                break;
            default:
                fragmentClass=ShopDashboards.class;
        }
        try{
            fragment=(Fragment) fragmentClass.newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }
        FragmentManager fragmentManager=getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frgDb,fragment).commit();
        btn.setVisibility(View.GONE);
        item.setChecked(true);
        setTitle(item.getTitle());
        drawerLayout.closeDrawers();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(toggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
