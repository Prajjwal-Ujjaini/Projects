package ZanwarTech.digitaludharkhata;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Gave extends AppCompatActivity implements WEB_URL {
    ProgressBar pbGave;
    CalendarView cvGave;

    EditText etGaveAmount;
    TextView etGaveDate;
    String strGaveAmount,strGaveDate,scId,strGotAmount,strGotDate ,selectDate;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    Button btnGaveSave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gave);

        etGaveAmount=findViewById(R.id.etGaveAmount);
        etGaveDate=findViewById(R.id.etGaveDate);
        pbGave=findViewById(R.id.pbGave);
        btnGaveSave=findViewById(R.id.btnGaveSave);

        cvGave = (CalendarView) findViewById(R.id.cvGave);

        cvGave.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectDate = dayOfMonth + "/" + (month + 1) + "/" + year;

                etGaveDate.setText(selectDate);
            }
        });

        sharedPreferences=getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        btnGaveSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SaveGaveAmount();
            }
        });
    }

    public void SaveGaveAmount(){
        scId=sharedPreferences.getString("scId","DEFAULT scId");
        //Toast.makeText(this, scId, Toast.LENGTH_SHORT).show();
        strGotAmount="";
        strGotDate="";
        strGaveAmount=etGaveAmount.getText().toString().trim();
        strGaveDate=selectDate;

        if (!TextUtils.isEmpty(scId) && !TextUtils.isEmpty(strGaveAmount) && !TextUtils.isEmpty(strGaveDate)) {
            pbGave.setVisibility(View.VISIBLE);
            final Map map=new HashMap();
            map.put("sc_id", scId);
            map.put("give_amount",strGaveAmount);
            map.put("given_date", strGaveDate);
            map.put("got_amount",strGotAmount);
            map.put("got_date",strGotDate );
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Url + "add_customer_transaction.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        //Toast.makeText(Gave.this, jsonObject.toString(), Toast.LENGTH_SHORT).show();
                        String data=jsonObject.getString("success");

                        if(data.equals("1")){
                            Intent intent=new Intent(getApplicationContext(),NavigationDrawer.class);
                            Toast.makeText(getApplicationContext(), "Amount Updated", Toast.LENGTH_SHORT).show();
                            pbGave.setVisibility(View.GONE);
                            startActivity(intent);
                        }else{
                            pbGave.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Amount Not Updated", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbGave.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), "catch run ==="+e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbGave.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), " error listnor run :==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueue.add(stringRequest);

        } else {
            pbGave.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }
}
