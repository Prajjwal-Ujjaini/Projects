package ZanwarTech.digitaludharkhata;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Got extends AppCompatActivity implements WEB_URL{
    ProgressBar pbGot;
    CalendarView cvGot;
    TextView etGotDate;
    EditText etGotAmount;
    String strGotAmount,strGotDate,scId,strGaveAmount,strGaveDate,selectDate;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    Button btnGotSave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_got);


        etGotAmount=findViewById(R.id.etGotAmount);
        etGotDate=findViewById(R.id.etGotDate);
        pbGot=findViewById(R.id.pbGot);
        btnGotSave=findViewById(R.id.btnGotSave);

        cvGot = (CalendarView) findViewById(R.id.cvGot);

        cvGot.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectDate = dayOfMonth + "/" + (month + 1) + "/" + year;

                etGotDate.setText(selectDate);
            }
        });


        sharedPreferences=getSharedPreferences("SP", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        btnGotSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SaveGotAmount();
            }
        });
    }

    public void SaveGotAmount(){
        scId=sharedPreferences.getString("scId","DEFAULT scId");
        //Toast.makeText(this, scId, Toast.LENGTH_SHORT).show();
        strGaveAmount="";
        strGaveDate="";
        strGotAmount=etGotAmount.getText().toString().trim();
        strGotDate=selectDate;

        if (!TextUtils.isEmpty(scId) && !TextUtils.isEmpty(strGotAmount) && !TextUtils.isEmpty(strGotDate)) {
            pbGot.setVisibility(View.VISIBLE);
            final Map map=new HashMap();
            map.put("sc_id", scId);
            map.put("got_amount",strGotAmount);
            map.put("got_date", strGotDate);
            map.put("give_amount",strGaveAmount);
            map.put("given_date", strGaveDate);

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Url + "add_customer_transaction.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        String data=jsonObject.getString("success");
                        if(data.equals("1")){
                            Intent intent=new Intent(getApplicationContext(),NavigationDrawer.class);
                            Toast.makeText(getApplicationContext(), "Amount Updated", Toast.LENGTH_SHORT).show();
                            pbGot.setVisibility(View.GONE);
                            startActivity(intent);
                        }else{
                            pbGot.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Amount Not Updated", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("catch error:", e.toString());
                        pbGot.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), /*"catch run ==="+*/ e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("error", error.toString());
                    pbGot.setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(), " error listnor run :==="+ error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    return map;
                }
            };
            requestQueue.add(stringRequest);

        } else {
            pbGot.setVisibility(View.GONE);
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
        }
    }

}
