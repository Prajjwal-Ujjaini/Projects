package ZanwarTech.digitaludharkhata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.Locale;

import ZanwarTech.digitaludharkhata.Adapters.ChooseLanuageAdapter;

public class ChooseLanguage extends AppCompatActivity{
    GridView gridViewChooseLanguage;
    ChooseLanuageAdapter chooseLanuageAdapter;

    String languagreName[]={"English","Hindi","Bengali","Urdu","Punjabi","Marathi","Telugu","Tamil","Gujarati","Kannada","Malayalam"};
    String langCode[]={"en","hi","bn","ur","pa","mr","te","ta","gu","kn","ml"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_language);

        gridViewChooseLanguage=findViewById(R.id.gvCLanguage);

        chooseLanuageAdapter=new ChooseLanuageAdapter(getApplicationContext(),languagreName);
        gridViewChooseLanguage.setAdapter(chooseLanuageAdapter);

        gridViewChooseLanguage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(ChooseLanguage.this, langCode[position], Toast.LENGTH_SHORT).show();

                setLocale(langCode[position]);
                Intent intent=new Intent(getApplicationContext(),FrontChoise.class);
                startActivity(intent);
            }
        });

    }

    public void setLocale(String lang){
        Locale locale=new Locale(lang);
        Locale.setDefault(locale);
        Configuration config=new Configuration();
        config.locale=locale;
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor=getSharedPreferences("SP",MODE_PRIVATE).edit();
        editor.putString("MY_Lang",lang);
        editor.commit();
    }

    public void loadLoacl(){
        SharedPreferences prefs=getSharedPreferences("SP",MODE_PRIVATE);
        String language=prefs.getString("My_Lang","DEFAULT lang");
        setLocale(language);
    }

}
